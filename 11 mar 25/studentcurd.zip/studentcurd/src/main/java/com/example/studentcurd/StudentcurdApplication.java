package com.example.studentcurd;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class StudentcurdApplication {

	public static void main(String[] args) {
		SpringApplication.run(StudentcurdApplication.class, args);
	}

}
